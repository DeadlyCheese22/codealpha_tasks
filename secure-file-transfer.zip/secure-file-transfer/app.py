import os
from flask import Flask, request, jsonify, render_template
from werkzeug.utils import secure_filename
import base64
from cryptography.hazmat.primitives import serialization, padding, hashes
from cryptography.hazmat.primitives.asymmetric import rsa

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'

# Generate server RSA keys
server_private_key = rsa.generate_private_key(
    public_exponent=65537,
    key_size=2048,
)
server_public_key = server_private_key.public_key()

# Convert keys to PEM format for storage or sharing
server_public_key_pem = server_public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo
)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/public-key', methods=['GET'])
def get_public_key():
    return server_public_key_pem.decode('utf-8')

@app.route('/upload', methods=['POST'])
def upload_file():
    print("Upload request received.")
    if 'file' not in request.files or 'key' not in request.form:
        print("Error: No file or key part in the request.")
        return jsonify({"error": "No file or key part"}), 400

    file = request.files['file']
    encrypted_symmetric_key = request.form['key']

    if file.filename == '':
        print("Error: No selected file.")
        return jsonify({"error": "No selected file"}), 400

    encrypted_symmetric_key = base64.b64decode(encrypted_symmetric_key)

    # Decrypt the symmetric key with server's private key
    try:
        symmetric_key = server_private_key.decrypt(
            encrypted_symmetric_key,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
    except Exception as e:
        print(f"Error decrypting symmetric key: {e}")
        return jsonify({"error": "Symmetric key decryption failed"}), 500

    filename = secure_filename(file.filename)
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)

    try:
        # Save the encrypted file
        file.save(file_path)
        print(f"File saved successfully at: {file_path}")
    except Exception as e:
        print(f"Error saving file: {e}")
        return jsonify({"error": "File could not be saved"}), 500

    return jsonify({"message": "File uploaded successfully"}), 200

if __name__ == '__main__':
    app.run(debug=True)
