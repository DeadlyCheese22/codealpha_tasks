import { Buffer } from 'buffer';

const uploadForm = document.getElementById('uploadForm') as HTMLFormElement;
const fileInput = document.getElementById('fileInput') as HTMLInputElement;

uploadForm.addEventListener('submit', async (event) => {
    event.preventDefault();

    if (!fileInput.files || fileInput.files.length === 0) {
        alert('Please select a file.');
        return;
    }

    const file = fileInput.files[0];
    console.log(`Selected file: ${file.name}`);
    
    // Fetch server's public key
    let publicKey: CryptoKey;
    try {
        const response = await fetch('/public-key');
        const publicKeyPem = await response.text();
        publicKey = await window.crypto.subtle.importKey(
            'spki',
            new Uint8Array(Buffer.from(publicKeyPem)),
            {
                name: 'RSA-OAEP',
                hash: 'SHA-256',
            },
            true,
            ['encrypt']
        );
        console.log('Public key fetched and imported.');
    } catch (error) {
        console.error('Error fetching or importing public key:', error);
        alert('Error fetching or importing public key.');
        return;
    }

    // Generate a symmetric key (AES)
    let symmetricKey: CryptoKey;
    try {
        symmetricKey = await window.crypto.subtle.generateKey(
            {
                name: 'AES-GCM',
                length: 256,
            },
            true,
            ['encrypt', 'decrypt']
        );
        console.log('Symmetric key generated.');
    } catch (error) {
        console.error('Error generating symmetric key:', error);
        alert('Error generating symmetric key.');
        return;
    }

    // Encrypt the file with the symmetric key
    let encryptedFileData: ArrayBuffer;
    try {
        const fileData = await file.arrayBuffer();
        const iv = window.crypto.getRandomValues(new Uint8Array(12));
        encryptedFileData = await window.crypto.subtle.encrypt(
            {
                name: 'AES-GCM',
                iv: iv,
            },
            symmetricKey,
            fileData
        );
        console.log('File encrypted.');
    } catch (error) {
        console.error('Error encrypting file:', error);
        alert('Error encrypting file.');
        return;
    }

    // Export the symmetric key and encrypt it with the server's public key
    let encryptedSymmetricKey: ArrayBuffer;
    try {
        const exportedSymmetricKey = await window.crypto.subtle.exportKey('raw', symmetricKey);
        encryptedSymmetricKey = await window.crypto.subtle.encrypt(
            {
                name: 'RSA-OAEP',
            },
            publicKey,
            exportedSymmetricKey
        );
        console.log('Symmetric key encrypted.');
    } catch (error) {
        console.error('Error exporting or encrypting symmetric key:', error);
        alert('Error exporting or encrypting symmetric key.');
        return;
    }

    // Create FormData to send the file and encrypted key
    const formData = new FormData();
    formData.append('file', new Blob([encryptedFileData]), file.name);

    // Convert Uint8Array to array of bytes (numbers) and then map each to a string character
    const encryptedKeyBytes = Array.from(new Uint8Array(encryptedSymmetricKey));
    const encryptedKeyString = encryptedKeyBytes.map(byte => String.fromCharCode(byte)).join('');
    
    formData.append('key', btoa(encryptedKeyString));
    

    // Send the file to the server
    try {
        const uploadResponse = await fetch('/upload', {
            method: 'POST',
            body: formData,
        });

        const uploadResult = await uploadResponse.json();
        console.log('Upload response:', uploadResult);
        alert(uploadResult.message);
    } catch (error) {
        console.error('Error uploading file:', error);
        alert('Error uploading file.');
    }
});
